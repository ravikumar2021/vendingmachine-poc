INSERT INTO Item_and_Price (id,item_name, item_price) VALUES
  (1,'Coke', '40'),
  (2,'Sprite', '30'),  
  (3,'Pepsi', '50');
