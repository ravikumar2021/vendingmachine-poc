CREATE TABLE item_and_price (
  id INT PRIMARY KEY,
  item_name VARCHAR(50) NOT NULL,
  item_price VARCHAR(20) NOT NULL,
);

