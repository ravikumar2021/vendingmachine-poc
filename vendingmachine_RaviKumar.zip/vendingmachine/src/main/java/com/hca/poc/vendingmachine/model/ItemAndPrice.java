package com.hca.poc.vendingmachine.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ItemAndPrice {
	@Id
	@GeneratedValue
	private int id;
	private String itemName;
	private int itemPrice;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	@Override
	public String toString() {
		return "ItemAndPrice [id=" + id + ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", getId()=" + getId()
				+ ", getItemName()=" + getItemName() + ", getItemPrice()=" + getItemPrice() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
