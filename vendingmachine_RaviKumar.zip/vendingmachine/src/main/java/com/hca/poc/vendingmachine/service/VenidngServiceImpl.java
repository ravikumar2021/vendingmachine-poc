package com.hca.poc.vendingmachine.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hca.poc.vendingmachine.dao.VendingmachineRepo;
import com.hca.poc.vendingmachine.model.ItemAndPrice;
import com.hca.poc.vendingmachine.model.ItemDetails;

@Service
public class VenidngServiceImpl implements VenidngService {

	@Autowired
	public VendingmachineRepo vendingMachineRepo;

	@Override
	public List<ItemAndPrice> getItemAndPrices() {
		List<ItemAndPrice> itemsPrice = new ArrayList<ItemAndPrice>();
		vendingMachineRepo.findAll().forEach(itemPrice -> itemsPrice.add(itemPrice));
		return itemsPrice;
	}

	@Override
	public String compute(ItemDetails model) {
		ItemAndPrice itemAndPrice = vendingMachineRepo.findById(model.getId()).get();
		int priceFromDB = itemAndPrice.getItemPrice();
		Integer difference = Integer.compare(priceFromDB, model.getItemPrice());

		// to load properties file
		Properties prop = new Properties();
		try {
			prop.load(getClass().getClassLoader().getResourceAsStream("application.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		String message = null;
		if (difference > 0) {
			message = (String) prop.get("insufficient.message");
			int cost = priceFromDB - model.getItemPrice();  
			message = message.replace("cost", String.valueOf(cost));
		} else if (difference == 0) {
			message = (String) prop.get("exact.message");
			message = message.replace("item", itemAndPrice.getItemName());
		} else if (difference < 0) {
			int change = model.getItemPrice() - priceFromDB;
			message = (String) prop.get("excess.message");
			message = message.replace("item", itemAndPrice.getItemName());
			message = message.replace("difference", String.valueOf(change));
		}
		return message;
	}
}
