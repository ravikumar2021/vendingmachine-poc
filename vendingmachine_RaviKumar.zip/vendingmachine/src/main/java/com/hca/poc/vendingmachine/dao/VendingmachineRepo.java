package com.hca.poc.vendingmachine.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hca.poc.vendingmachine.model.ItemAndPrice;

@Repository
public interface VendingmachineRepo extends CrudRepository<ItemAndPrice, Integer> {

}
