package com.hca.poc.vendingmachine.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.hca.poc.vendingmachine.model.ItemAndPrice;
import com.hca.poc.vendingmachine.model.ItemDetails;
import com.hca.poc.vendingmachine.service.VenidngService;

@Controller
public class VendingmachineController {

	@Autowired
	public VenidngService vendingService;

	//To display all items existed in database
	@GetMapping("/")
	public String getItemAndPrices(Model model) {
		List<ItemAndPrice> itemPrice = vendingService.getItemAndPrices();
		model.addAttribute("itemList", itemPrice);
		model.addAttribute("itemModel", new ItemDetails());
		return "VendingMachine";
	}
	
	//To do calculations after user enters item id and price
	@PostMapping("/vending/check/")
	public String computeRetrun(Model model, @ModelAttribute ItemDetails itemModel) {
		String message = vendingService.compute(itemModel);
		model.addAttribute("message", message);
		return "result";
	}

}