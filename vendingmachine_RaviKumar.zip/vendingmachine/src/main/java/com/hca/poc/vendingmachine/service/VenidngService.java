package com.hca.poc.vendingmachine.service;

import java.util.List;

import com.hca.poc.vendingmachine.model.ItemAndPrice;
import com.hca.poc.vendingmachine.model.ItemDetails;

public interface VenidngService {
	public List<ItemAndPrice> getItemAndPrices();

	public String compute(ItemDetails model);
}
