package com.hca.poc.vendingmachine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendingmachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
